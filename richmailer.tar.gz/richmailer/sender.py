import email, smtplib, ssl
import xml.dom
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from xml.dom import minidom
import urllib.request
import csv
from os import listdir
from os import walk
from os.path import isfile, join

def file_get_contents(filename, use_include_path = 0, context = None, offset = -1, maxlen = -1):
    if(filename.find('://') > 0):
      ret = urlib.request.urlopen(filename).read()
      if (offset > 0):
           ret = ret[offset:]
      if (maxlen > 0):
           ret = ret[:maxlen]
      return ret
    else:
       fp = open(filename, 'rb')
       try:
          if(offset > 0):
             fp.seek(offset)
          ret = fp.read(maxlen)
          return ret
       finally:
          fp.close()

def folder_list (dir_name):
     #onlyfiles = [f for f in listdir("pieces/"+dir_name) if isfile(join("pieces/"+dir_name, f))]
     f = []
     for (dirpath, dirnames, filenames) in walk(dir_name):
       f.extend(filenames)
       break
     return f

def set_attach_files(message, filename):
   # Open PDF file in binary mode
  with open(filename, "rb") as attachment:
    # Add file as application/octet-stream
    # Email client can usually download this automatically as attachment
    part = MIMEBase("application", "octet-stream")
    part.set_payload(attachment.read())
    # Encode file in ASCII characters to send by email    
    encoders.encode_base64(part)
    # Add header as key/value pair to attachment part
    part.add_header(
      "Content-Disposition",
     "attachment; filename= "+filename
    )
    message.attach(part)
       

xml_content = file_get_contents('config/config.xml');
xmldoc = minidom.parseString(xml_content)
HOSTNAME = xmldoc.getElementsByTagName('host_name')[0].firstChild.data
USERNAME = xmldoc.getElementsByTagName('user_name')[0].firstChild.data
PASSWORD = xmldoc.getElementsByTagName('password')[0].firstChild.data
PORT = xmldoc.getElementsByTagName('port')[0].firstChild.data
FROM = xmldoc.getElementsByTagName('from')[0].firstChild.data
CC = xmldoc.getElementsByTagName('cc')[0].firstChild.data
BCC = xmldoc.getElementsByTagName('bcc')[0].firstChild.data
SUBJECT = xmldoc.getElementsByTagName('subject')[0].firstChild.data
ATTACHMENT_FOLDER = xmldoc.getElementsByTagName('attachment_folder')[0].firstChild.data
CONTENT_FILE = xmldoc.getElementsByTagName('content_file')[0].firstChild.data
BODY = file_get_contents("messages/"+CONTENT_FILE)
DESTINATION_FOLDER = xmldoc.getElementsByTagName('destination_folder')[0].firstChild.data
filenames = folder_list ("pieces/"+ATTACHMENT_FOLDER)

def get_complete_mail_content (filenames, receiver_email):
  # Create a multipart message and set headers
  message = MIMEMultipart()
  message["From"] = FROM
  message["To"] = receiver_email
  message["Subject"] = SUBJECT
  message["Cc"] = CC
  message["Bcc"] = BCC
 
  # Add body to email
  message.attach(MIMEText(BODY, "html", "utf-8"))
  
  for fname in filenames :
    set_attach_files(message, "pieces/"+ATTACHMENT_FOLDER+"/"+fname)
  text = message.as_string()
  return text

def send_mail_from_csv(server, csv_file):
  with open(csv_file) as fichier:
   try:
    reader = csv.reader(fichier)
    next(reader)
    print ("SENDING MAIL TO RECEIVERS FROM ", csv_file, " : \n ")
    for _email in reader:
     text = get_complete_mail_content(filenames, _email[0])
     server.sendmail(FROM, _email[0], text)
     print("sent -->  ",_email[0])
   except:
     print("Exception occured")
   finally:
     print ("MAILS SENT TO RECEIVERS FROM "+csv_file+" : \n ")

def send_contact_folder (server, dir_name):
  csv_files = folder_list(dir_name)
  for csv_file in csv_files:
    send_mail_from_csv(server, dir_name+"/"+csv_file)    

#PERFORMING THE JOB NOW
with smtplib.SMTP(HOSTNAME, PORT) as server:
    server.login(USERNAME, PASSWORD)
    send_contact_folder(server, "contacts/"+DESTINATION_FOLDER)
